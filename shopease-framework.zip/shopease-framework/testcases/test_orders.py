import pytest

from config import OTHER_ORDER_ID
from api.order_api import OrderApi
from api.product_api import ProductApi


@pytest.mark.smoke
def test_guest_cannot_see_orders(guest):
    r = OrderApi(guest).list_orders()
    assert r.status_code == 401
    assert r.json()["message"] == "Please login first"


def test_customer_sees_only_own_orders(customer):
    body = OrderApi(customer).list_orders().json()
    assert body["success"] is True
    for order in body["orders"]:
        assert int(order["user_id"]) == customer.user_id


def test_customer_cannot_see_others_order(customer):
    body = OrderApi(customer).get_order(OTHER_ORDER_ID).json()
    assert body["message"] == "Order not found"


def test_customer_cannot_update_status(customer):
    r = OrderApi(customer).update_status(1, "Shipped")
    assert r.status_code == 403
    assert r.json()["message"] == "Admin only"


def test_order_price_cannot_be_tampered(customer, guest):
    product = ProductApi(guest).get_product(2).json()["products"][0]
    items = [{"id": 2, "name": product["name"], "price": 0.01, "quantity": 2}]
    body = OrderApi(customer).create_order(items, customer.user_id, 0.01).json()
    assert body["success"] is True
    order = OrderApi(customer).get_order(body["order_id"]).json()["orders"][0]
    assert float(order["total_price"]) == float(product["price"]) * 2