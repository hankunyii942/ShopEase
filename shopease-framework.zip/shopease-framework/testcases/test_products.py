from api.product_api import ProductApi


def test_product_by_id(guest):
    body = ProductApi(guest).get_product(1).json()
    assert body["success"] is True
    assert len(body["products"]) == 1
    assert "iPhone" in body["products"][0]["name"]