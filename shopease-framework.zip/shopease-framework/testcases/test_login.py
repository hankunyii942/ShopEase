import pytest

from config import EMAIL, PASSWORD
from api.user_api import UserApi
from common.data_util import load_yaml

invalid_cases = load_yaml("login_cases.yaml")


@pytest.mark.smoke
def test_login_success(guest):
    body = UserApi(guest).login(EMAIL, PASSWORD).json()
    assert body["success"] is True
    assert body["user"]["role"] == "customer"


@pytest.mark.parametrize("case", invalid_cases, ids=[c["id"] for c in invalid_cases])
def test_login_invalid(guest, case):
    body = UserApi(guest).login(case["email"], case["password"]).json()
    assert body["success"] is False
    assert case["expected"] in body["message"]