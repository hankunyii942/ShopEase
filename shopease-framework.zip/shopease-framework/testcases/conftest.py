import pytest

from config import EMAIL, PASSWORD
from common.request_util import RequestUtil
from api.user_api import UserApi


@pytest.fixture(scope="session")
def customer():
    client = RequestUtil()
    body = UserApi(client).login(EMAIL, PASSWORD).json()
    assert body["success"] is True
    client.user_id = int(body["user"]["id"])
    yield client
    UserApi(client).logout()


@pytest.fixture
def guest():
    return RequestUtil()