import os

BASE_URL = os.getenv("SHOPEASE_BASE_URL", "http://localhost/shopease/api")
EMAIL = os.getenv("SHOPEASE_EMAIL", "xss1@test.com")
PASSWORD = os.getenv("SHOPEASE_PASSWORD", "123456")
TIMEOUT = 10
OTHER_ORDER_ID = int(os.getenv("SHOPEASE_OTHER_ORDER_ID", "17"))