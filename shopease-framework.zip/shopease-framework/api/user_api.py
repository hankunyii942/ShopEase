class UserApi:
    def __init__(self, client):
        self.client = client

    def login(self, email, password):
        return self.client.send("POST", "users.php", json={
            "action": "login",
            "email": email,
            "password": password
        })

    def logout(self):
        return self.client.send("POST", "users.php", json={"action": "logout"})