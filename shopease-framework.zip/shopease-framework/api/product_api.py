class ProductApi:
    def __init__(self, client):
        self.client = client

    def get_product(self, product_id):
        return self.client.send("GET", "products.php", params={"id": product_id})