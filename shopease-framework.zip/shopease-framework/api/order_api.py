class OrderApi:
    def __init__(self, client):
        self.client = client

    def list_orders(self):
        return self.client.send("GET", "orders.php")

    def get_order(self, order_id):
        return self.client.send("GET", "orders.php", params={"id": order_id})

    def create_order(self, items, user_id, total_price):
        return self.client.send("POST", "orders.php", json={
            "items": items,
            "total_price": total_price,
            "payment_method": "alipay",
            "shipping_name": "Test User",
            "shipping_phone": "0123456789",
            "shipping_address": "Test Address",
            "user_id": user_id
        })

    def update_status(self, order_id, status):
        return self.client.send("POST", "orders.php",
                                params={"action": "update_status"},
                                json={"order_id": order_id, "status": status})