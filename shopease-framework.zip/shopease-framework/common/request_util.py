import requests

from config import BASE_URL, TIMEOUT


class RequestUtil:
    def __init__(self):
        self.session = requests.Session()

    def send(self, method, path, **kwargs):
        url = f"{BASE_URL}/{path}"
        kwargs.setdefault("timeout", TIMEOUT)
        r = self.session.request(method, url, **kwargs)
        print(f"{method} {url} params={kwargs.get('params')} json={kwargs.get('json')}")
        print(f"-> {r.status_code} {r.text[:200]}")
        return r