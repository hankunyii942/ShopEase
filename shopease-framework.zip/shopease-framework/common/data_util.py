import os

import yaml

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")


def load_yaml(file_name):
    with open(os.path.join(DATA_DIR, file_name), encoding="utf-8") as f:
        return yaml.safe_load(f)