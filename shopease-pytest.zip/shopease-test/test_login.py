import pytest
import requests

BASE = "http://localhost/shopease/api"

@pytest.mark.smoke
def test_login_success():
    r = requests.post(f"{BASE}/users.php", json={
        "action": "login",
        "email": "xss1@test.com",
        "password": "123456"
    })
    body = r.json()
    assert r.status_code == 200
    assert body["success"] is True
    assert body["user"]["role"] == "customer"


def test_login_wrong_password():
    r = requests.post(f"{BASE}/users.php", json={
        "action": "login",
        "email": "xss1@test.com",
        "password": "wrong123"
    })
    body = r.json()
    assert body["success"] is False
    assert "Incorrect email or password" in body["message"]

@pytest.mark.smoke
def test_orders_require_login():
    r = requests.get(f"{BASE}/orders.php")
    assert r.status_code == 401
    assert r.json()["message"] == "Please login first"
@pytest.mark.parametrize("email, password, expected", [
    ("xss1@test.com", "wrong123", "Incorrect email or password"),
    ("notanemail", "123456", "Invalid email format"),
    ("nobody999@test.com", "123456", "Incorrect email or password"),
    ("' OR '1'='1", "x", "Invalid email format"),
    ("", "123456", "Please enter your email and password"),
], ids=["wrong_password", "bad_email_format", "not_registered", "sql_injection", "empty_email"])
def test_login_invalid(base_url, email, password, expected):
    r = requests.post(f"{base_url}/users.php", json={
        "action": "login",
        "email": email,
        "password": password
    })
    body = r.json()
    assert body["success"] is False
    assert expected in body["message"]