import requests

BASE = "http://localhost/shopease/api"

s = requests.Session()

r = s.post(f"{BASE}/users.php", json={
    "action": "login",
    "email": "xss1@test.com",
    "password": "123456"
})
body = r.json()
assert r.status_code == 200
assert body["success"] is True
assert body["user"]["role"] == "customer"
print("通过：普通用户登录成功")

r = s.get(f"{BASE}/orders.php")
body = r.json()
assert r.status_code == 200
assert body["success"] is True
for order in body["orders"]:
    assert int(order["user_id"]) == 17
print("通过：普通用户只能看到自己的", len(body["orders"]), "条订单")

r = requests.get(f"{BASE}/orders.php")
assert r.status_code == 401
assert r.json()["message"] == "Please login first"
print("通过：未登录查订单被拒绝")