import requests


def test_customer_sees_only_own_orders(customer, base_url):
    r = customer.get(f"{base_url}/orders.php")
    body = r.json()
    assert body["success"] is True
    for order in body["orders"]:
        assert int(order["user_id"]) == 17


def test_customer_cannot_see_others_order(customer, base_url):
    r = customer.get(f"{base_url}/orders.php", params={"id": 17})
    assert r.json()["message"] == "Order not found"


def test_customer_cannot_update_status(customer, base_url):
    r = customer.post(f"{base_url}/orders.php",
                      params={"action": "update_status"},
                      json={"order_id": 1, "status": "Shipped"})
    assert r.status_code == 403
    assert r.json()["message"] == "Admin only"


def test_guest_cannot_see_orders(base_url):
    r = requests.get(f"{base_url}/orders.php")
    assert r.status_code == 401