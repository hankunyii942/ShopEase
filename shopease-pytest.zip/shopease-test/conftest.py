import pytest
import requests

BASE = "http://localhost/shopease/api"


@pytest.fixture(scope="session")
def base_url():
    return BASE


@pytest.fixture(scope="session")
def customer():
    s = requests.Session()
    r = s.post(f"{BASE}/users.php", json={
        "action": "login",
        "email": "xss1@test.com",
        "password": "123456"
    })
    assert r.json()["success"] is True
    yield s
    s.post(f"{BASE}/users.php", json={"action": "logout"})